/**
 * Data Access Objects used by WebSocket services.
 */
package com.tradeprocess.admin.web.websocket.dto;
