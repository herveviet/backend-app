/**
 * Service layer beans.
 */
package com.tradeprocess.admin.service;
