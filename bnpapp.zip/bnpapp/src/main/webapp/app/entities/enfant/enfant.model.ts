import { BaseEntity } from './../../shared';

export const enum Type {
    'type1',
    'type2',
    'type3'
}

export class Enfant implements BaseEntity {
    constructor(
        public id?: number,
        public name?: string,
        public age?: number,
        public quartier?: string,
        public dateNaiss?: any,
        public type?: Type,
        public enabled?: boolean,
        public field0?: number,
        public field1?: number,
        public field2?: any,
        public parents?: BaseEntity[],
        public parent1Id?: number,
        public parent2Id?: number,
        public parent3Id?: number,
    ) {
        this.enabled = false;
    }
}
