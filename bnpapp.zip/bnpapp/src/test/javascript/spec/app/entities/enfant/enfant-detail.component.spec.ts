/* tslint:disable max-line-length */
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

import { TradeprocessadminTestModule } from '../../../test.module';
import { EnfantDetailComponent } from '../../../../../../main/webapp/app/entities/enfant/enfant-detail.component';
import { EnfantService } from '../../../../../../main/webapp/app/entities/enfant/enfant.service';
import { Enfant } from '../../../../../../main/webapp/app/entities/enfant/enfant.model';

describe('Component Tests', () => {

    describe('Enfant Management Detail Component', () => {
        let comp: EnfantDetailComponent;
        let fixture: ComponentFixture<EnfantDetailComponent>;
        let service: EnfantService;

        beforeEach(async(() => {
            TestBed.configureTestingModule({
                imports: [TradeprocessadminTestModule],
                declarations: [EnfantDetailComponent],
                providers: [
                    EnfantService
                ]
            })
            .overrideTemplate(EnfantDetailComponent, '')
            .compileComponents();
        }));

        beforeEach(() => {
            fixture = TestBed.createComponent(EnfantDetailComponent);
            comp = fixture.componentInstance;
            service = fixture.debugElement.injector.get(EnfantService);
        });

        describe('OnInit', () => {
            it('Should call load all on init', () => {
                // GIVEN

                spyOn(service, 'find').and.returnValue(Observable.of(new HttpResponse({
                    body: new Enfant(123)
                })));

                // WHEN
                comp.ngOnInit();

                // THEN
                expect(service.find).toHaveBeenCalledWith(123);
                expect(comp.enfant).toEqual(jasmine.objectContaining({id: 123}));
            });
        });
    });

});
