package com.tradeprocess.admin.service.mapper;

import com.tradeprocess.admin.domain.*;
import com.tradeprocess.admin.service.dto.EnfantDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Enfant and its DTO EnfantDTO.
 */
@Mapper(componentModel = "spring", uses = {ParentMapper.class})
public interface EnfantMapper extends EntityMapper<EnfantDTO, Enfant> {

    @Mapping(source = "parent1.id", target = "parent1Id")
    @Mapping(source = "parent2.id", target = "parent2Id")
    @Mapping(source = "parent3.id", target = "parent3Id")
    EnfantDTO toDto(Enfant enfant);

    @Mapping(target = "parents", ignore = true)
    @Mapping(source = "parent1Id", target = "parent1")
    @Mapping(source = "parent2Id", target = "parent2")
    @Mapping(source = "parent3Id", target = "parent3")
    Enfant toEntity(EnfantDTO enfantDTO);

    default Enfant fromId(Long id) {
        if (id == null) {
            return null;
        }
        Enfant enfant = new Enfant();
        enfant.setId(id);
        return enfant;
    }
}
