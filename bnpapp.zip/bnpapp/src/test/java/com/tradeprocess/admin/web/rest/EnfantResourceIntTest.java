package com.tradeprocess.admin.web.rest;

import com.tradeprocess.admin.TradeprocessadminApp;

import com.tradeprocess.admin.domain.Enfant;
import com.tradeprocess.admin.domain.Parent;
import com.tradeprocess.admin.domain.Parent;
import com.tradeprocess.admin.domain.Parent;
import com.tradeprocess.admin.domain.Parent;
import com.tradeprocess.admin.repository.EnfantRepository;
import com.tradeprocess.admin.service.EnfantService;
import com.tradeprocess.admin.service.dto.EnfantDTO;
import com.tradeprocess.admin.service.mapper.EnfantMapper;
import com.tradeprocess.admin.web.rest.errors.ExceptionTranslator;
import com.tradeprocess.admin.service.dto.EnfantCriteria;
import com.tradeprocess.admin.service.EnfantQueryService;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.ZoneOffset;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static com.tradeprocess.admin.web.rest.TestUtil.sameInstant;
import static com.tradeprocess.admin.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.tradeprocess.admin.domain.enumeration.Type;
/**
 * Test class for the EnfantResource REST controller.
 *
 * @see EnfantResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TradeprocessadminApp.class)
public class EnfantResourceIntTest {

    private static final String DEFAULT_NAME = "AAAAAAAAAA";
    private static final String UPDATED_NAME = "BBBBBBBBBB";

    private static final Integer DEFAULT_AGE = 1;
    private static final Integer UPDATED_AGE = 2;

    private static final String DEFAULT_QUARTIER = "AAAAAAAAAA";
    private static final String UPDATED_QUARTIER = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_DATE_NAISS = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_DATE_NAISS = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final Type DEFAULT_TYPE = Type.type1;
    private static final Type UPDATED_TYPE = Type.type2;

    private static final Boolean DEFAULT_ENABLED = false;
    private static final Boolean UPDATED_ENABLED = true;

    private static final Float DEFAULT_FIELD_0 = 1F;
    private static final Float UPDATED_FIELD_0 = 2F;

    private static final Long DEFAULT_FIELD_1 = 1L;
    private static final Long UPDATED_FIELD_1 = 2L;

    private static final Instant DEFAULT_FIELD_2 = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_FIELD_2 = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    @Autowired
    private EnfantRepository enfantRepository;

    @Autowired
    private EnfantMapper enfantMapper;

    @Autowired
    private EnfantService enfantService;

    @Autowired
    private EnfantQueryService enfantQueryService;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    private MockMvc restEnfantMockMvc;

    private Enfant enfant;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final EnfantResource enfantResource = new EnfantResource(enfantService, enfantQueryService);
        this.restEnfantMockMvc = MockMvcBuilders.standaloneSetup(enfantResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Enfant createEntity(EntityManager em) {
        Enfant enfant = new Enfant()
            .name(DEFAULT_NAME)
            .age(DEFAULT_AGE)
            .quartier(DEFAULT_QUARTIER)
            .dateNaiss(DEFAULT_DATE_NAISS)
            .type(DEFAULT_TYPE)
            .enabled(DEFAULT_ENABLED)
            .field0(DEFAULT_FIELD_0)
            .field1(DEFAULT_FIELD_1)
            .field2(DEFAULT_FIELD_2);
        return enfant;
    }

    @Before
    public void initTest() {
        enfant = createEntity(em);
    }

    @Test
    @Transactional
    public void createEnfant() throws Exception {
        int databaseSizeBeforeCreate = enfantRepository.findAll().size();

        // Create the Enfant
        EnfantDTO enfantDTO = enfantMapper.toDto(enfant);
        restEnfantMockMvc.perform(post("/api/enfants")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(enfantDTO)))
            .andExpect(status().isCreated());

        // Validate the Enfant in the database
        List<Enfant> enfantList = enfantRepository.findAll();
        assertThat(enfantList).hasSize(databaseSizeBeforeCreate + 1);
        Enfant testEnfant = enfantList.get(enfantList.size() - 1);
        assertThat(testEnfant.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testEnfant.getAge()).isEqualTo(DEFAULT_AGE);
        assertThat(testEnfant.getQuartier()).isEqualTo(DEFAULT_QUARTIER);
        assertThat(testEnfant.getDateNaiss()).isEqualTo(DEFAULT_DATE_NAISS);
        assertThat(testEnfant.getType()).isEqualTo(DEFAULT_TYPE);
        assertThat(testEnfant.isEnabled()).isEqualTo(DEFAULT_ENABLED);
        assertThat(testEnfant.getField0()).isEqualTo(DEFAULT_FIELD_0);
        assertThat(testEnfant.getField1()).isEqualTo(DEFAULT_FIELD_1);
        assertThat(testEnfant.getField2()).isEqualTo(DEFAULT_FIELD_2);
    }

    @Test
    @Transactional
    public void createEnfantWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = enfantRepository.findAll().size();

        // Create the Enfant with an existing ID
        enfant.setId(1L);
        EnfantDTO enfantDTO = enfantMapper.toDto(enfant);

        // An entity with an existing ID cannot be created, so this API call must fail
        restEnfantMockMvc.perform(post("/api/enfants")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(enfantDTO)))
            .andExpect(status().isBadRequest());

        // Validate the Enfant in the database
        List<Enfant> enfantList = enfantRepository.findAll();
        assertThat(enfantList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void getAllEnfants() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList
        restEnfantMockMvc.perform(get("/api/enfants?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(enfant.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].age").value(hasItem(DEFAULT_AGE)))
            .andExpect(jsonPath("$.[*].quartier").value(hasItem(DEFAULT_QUARTIER.toString())))
            .andExpect(jsonPath("$.[*].dateNaiss").value(hasItem(sameInstant(DEFAULT_DATE_NAISS))))
            .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE.toString())))
            .andExpect(jsonPath("$.[*].enabled").value(hasItem(DEFAULT_ENABLED.booleanValue())))
            .andExpect(jsonPath("$.[*].field0").value(hasItem(DEFAULT_FIELD_0.doubleValue())))
            .andExpect(jsonPath("$.[*].field1").value(hasItem(DEFAULT_FIELD_1.intValue())))
            .andExpect(jsonPath("$.[*].field2").value(hasItem(DEFAULT_FIELD_2.toString())));
    }

    @Test
    @Transactional
    public void getEnfant() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get the enfant
        restEnfantMockMvc.perform(get("/api/enfants/{id}", enfant.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(enfant.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.age").value(DEFAULT_AGE))
            .andExpect(jsonPath("$.quartier").value(DEFAULT_QUARTIER.toString()))
            .andExpect(jsonPath("$.dateNaiss").value(sameInstant(DEFAULT_DATE_NAISS)))
            .andExpect(jsonPath("$.type").value(DEFAULT_TYPE.toString()))
            .andExpect(jsonPath("$.enabled").value(DEFAULT_ENABLED.booleanValue()))
            .andExpect(jsonPath("$.field0").value(DEFAULT_FIELD_0.doubleValue()))
            .andExpect(jsonPath("$.field1").value(DEFAULT_FIELD_1.intValue()))
            .andExpect(jsonPath("$.field2").value(DEFAULT_FIELD_2.toString()));
    }

    @Test
    @Transactional
    public void getAllEnfantsByNameIsEqualToSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where name equals to DEFAULT_NAME
        defaultEnfantShouldBeFound("name.equals=" + DEFAULT_NAME);

        // Get all the enfantList where name equals to UPDATED_NAME
        defaultEnfantShouldNotBeFound("name.equals=" + UPDATED_NAME);
    }

    @Test
    @Transactional
    public void getAllEnfantsByNameIsInShouldWork() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where name in DEFAULT_NAME or UPDATED_NAME
        defaultEnfantShouldBeFound("name.in=" + DEFAULT_NAME + "," + UPDATED_NAME);

        // Get all the enfantList where name equals to UPDATED_NAME
        defaultEnfantShouldNotBeFound("name.in=" + UPDATED_NAME);
    }

    @Test
    @Transactional
    public void getAllEnfantsByNameIsNullOrNotNull() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where name is not null
        defaultEnfantShouldBeFound("name.specified=true");

        // Get all the enfantList where name is null
        defaultEnfantShouldNotBeFound("name.specified=false");
    }

    @Test
    @Transactional
    public void getAllEnfantsByAgeIsEqualToSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where age equals to DEFAULT_AGE
        defaultEnfantShouldBeFound("age.equals=" + DEFAULT_AGE);

        // Get all the enfantList where age equals to UPDATED_AGE
        defaultEnfantShouldNotBeFound("age.equals=" + UPDATED_AGE);
    }

    @Test
    @Transactional
    public void getAllEnfantsByAgeIsInShouldWork() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where age in DEFAULT_AGE or UPDATED_AGE
        defaultEnfantShouldBeFound("age.in=" + DEFAULT_AGE + "," + UPDATED_AGE);

        // Get all the enfantList where age equals to UPDATED_AGE
        defaultEnfantShouldNotBeFound("age.in=" + UPDATED_AGE);
    }

    @Test
    @Transactional
    public void getAllEnfantsByAgeIsNullOrNotNull() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where age is not null
        defaultEnfantShouldBeFound("age.specified=true");

        // Get all the enfantList where age is null
        defaultEnfantShouldNotBeFound("age.specified=false");
    }

    @Test
    @Transactional
    public void getAllEnfantsByAgeIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where age greater than or equals to DEFAULT_AGE
        defaultEnfantShouldBeFound("age.greaterOrEqualThan=" + DEFAULT_AGE);

        // Get all the enfantList where age greater than or equals to UPDATED_AGE
        defaultEnfantShouldNotBeFound("age.greaterOrEqualThan=" + UPDATED_AGE);
    }

    @Test
    @Transactional
    public void getAllEnfantsByAgeIsLessThanSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where age less than or equals to DEFAULT_AGE
        defaultEnfantShouldNotBeFound("age.lessThan=" + DEFAULT_AGE);

        // Get all the enfantList where age less than or equals to UPDATED_AGE
        defaultEnfantShouldBeFound("age.lessThan=" + UPDATED_AGE);
    }


    @Test
    @Transactional
    public void getAllEnfantsByQuartierIsEqualToSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where quartier equals to DEFAULT_QUARTIER
        defaultEnfantShouldBeFound("quartier.equals=" + DEFAULT_QUARTIER);

        // Get all the enfantList where quartier equals to UPDATED_QUARTIER
        defaultEnfantShouldNotBeFound("quartier.equals=" + UPDATED_QUARTIER);
    }

    @Test
    @Transactional
    public void getAllEnfantsByQuartierIsInShouldWork() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where quartier in DEFAULT_QUARTIER or UPDATED_QUARTIER
        defaultEnfantShouldBeFound("quartier.in=" + DEFAULT_QUARTIER + "," + UPDATED_QUARTIER);

        // Get all the enfantList where quartier equals to UPDATED_QUARTIER
        defaultEnfantShouldNotBeFound("quartier.in=" + UPDATED_QUARTIER);
    }

    @Test
    @Transactional
    public void getAllEnfantsByQuartierIsNullOrNotNull() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where quartier is not null
        defaultEnfantShouldBeFound("quartier.specified=true");

        // Get all the enfantList where quartier is null
        defaultEnfantShouldNotBeFound("quartier.specified=false");
    }

    @Test
    @Transactional
    public void getAllEnfantsByDateNaissIsEqualToSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where dateNaiss equals to DEFAULT_DATE_NAISS
        defaultEnfantShouldBeFound("dateNaiss.equals=" + DEFAULT_DATE_NAISS);

        // Get all the enfantList where dateNaiss equals to UPDATED_DATE_NAISS
        defaultEnfantShouldNotBeFound("dateNaiss.equals=" + UPDATED_DATE_NAISS);
    }

    @Test
    @Transactional
    public void getAllEnfantsByDateNaissIsInShouldWork() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where dateNaiss in DEFAULT_DATE_NAISS or UPDATED_DATE_NAISS
        defaultEnfantShouldBeFound("dateNaiss.in=" + DEFAULT_DATE_NAISS + "," + UPDATED_DATE_NAISS);

        // Get all the enfantList where dateNaiss equals to UPDATED_DATE_NAISS
        defaultEnfantShouldNotBeFound("dateNaiss.in=" + UPDATED_DATE_NAISS);
    }

    @Test
    @Transactional
    public void getAllEnfantsByDateNaissIsNullOrNotNull() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where dateNaiss is not null
        defaultEnfantShouldBeFound("dateNaiss.specified=true");

        // Get all the enfantList where dateNaiss is null
        defaultEnfantShouldNotBeFound("dateNaiss.specified=false");
    }

    @Test
    @Transactional
    public void getAllEnfantsByDateNaissIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where dateNaiss greater than or equals to DEFAULT_DATE_NAISS
        defaultEnfantShouldBeFound("dateNaiss.greaterOrEqualThan=" + DEFAULT_DATE_NAISS);

        // Get all the enfantList where dateNaiss greater than or equals to UPDATED_DATE_NAISS
        defaultEnfantShouldNotBeFound("dateNaiss.greaterOrEqualThan=" + UPDATED_DATE_NAISS);
    }

    @Test
    @Transactional
    public void getAllEnfantsByDateNaissIsLessThanSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where dateNaiss less than or equals to DEFAULT_DATE_NAISS
        defaultEnfantShouldNotBeFound("dateNaiss.lessThan=" + DEFAULT_DATE_NAISS);

        // Get all the enfantList where dateNaiss less than or equals to UPDATED_DATE_NAISS
        defaultEnfantShouldBeFound("dateNaiss.lessThan=" + UPDATED_DATE_NAISS);
    }


    @Test
    @Transactional
    public void getAllEnfantsByTypeIsEqualToSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where type equals to DEFAULT_TYPE
        defaultEnfantShouldBeFound("type.equals=" + DEFAULT_TYPE);

        // Get all the enfantList where type equals to UPDATED_TYPE
        defaultEnfantShouldNotBeFound("type.equals=" + UPDATED_TYPE);
    }

    @Test
    @Transactional
    public void getAllEnfantsByTypeIsInShouldWork() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where type in DEFAULT_TYPE or UPDATED_TYPE
        defaultEnfantShouldBeFound("type.in=" + DEFAULT_TYPE + "," + UPDATED_TYPE);

        // Get all the enfantList where type equals to UPDATED_TYPE
        defaultEnfantShouldNotBeFound("type.in=" + UPDATED_TYPE);
    }

    @Test
    @Transactional
    public void getAllEnfantsByTypeIsNullOrNotNull() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where type is not null
        defaultEnfantShouldBeFound("type.specified=true");

        // Get all the enfantList where type is null
        defaultEnfantShouldNotBeFound("type.specified=false");
    }

    @Test
    @Transactional
    public void getAllEnfantsByEnabledIsEqualToSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where enabled equals to DEFAULT_ENABLED
        defaultEnfantShouldBeFound("enabled.equals=" + DEFAULT_ENABLED);

        // Get all the enfantList where enabled equals to UPDATED_ENABLED
        defaultEnfantShouldNotBeFound("enabled.equals=" + UPDATED_ENABLED);
    }

    @Test
    @Transactional
    public void getAllEnfantsByEnabledIsInShouldWork() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where enabled in DEFAULT_ENABLED or UPDATED_ENABLED
        defaultEnfantShouldBeFound("enabled.in=" + DEFAULT_ENABLED + "," + UPDATED_ENABLED);

        // Get all the enfantList where enabled equals to UPDATED_ENABLED
        defaultEnfantShouldNotBeFound("enabled.in=" + UPDATED_ENABLED);
    }

    @Test
    @Transactional
    public void getAllEnfantsByEnabledIsNullOrNotNull() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where enabled is not null
        defaultEnfantShouldBeFound("enabled.specified=true");

        // Get all the enfantList where enabled is null
        defaultEnfantShouldNotBeFound("enabled.specified=false");
    }

    @Test
    @Transactional
    public void getAllEnfantsByField0IsEqualToSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where field0 equals to DEFAULT_FIELD_0
        defaultEnfantShouldBeFound("field0.equals=" + DEFAULT_FIELD_0);

        // Get all the enfantList where field0 equals to UPDATED_FIELD_0
        defaultEnfantShouldNotBeFound("field0.equals=" + UPDATED_FIELD_0);
    }

    @Test
    @Transactional
    public void getAllEnfantsByField0IsInShouldWork() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where field0 in DEFAULT_FIELD_0 or UPDATED_FIELD_0
        defaultEnfantShouldBeFound("field0.in=" + DEFAULT_FIELD_0 + "," + UPDATED_FIELD_0);

        // Get all the enfantList where field0 equals to UPDATED_FIELD_0
        defaultEnfantShouldNotBeFound("field0.in=" + UPDATED_FIELD_0);
    }

    @Test
    @Transactional
    public void getAllEnfantsByField0IsNullOrNotNull() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where field0 is not null
        defaultEnfantShouldBeFound("field0.specified=true");

        // Get all the enfantList where field0 is null
        defaultEnfantShouldNotBeFound("field0.specified=false");
    }

    @Test
    @Transactional
    public void getAllEnfantsByField1IsEqualToSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where field1 equals to DEFAULT_FIELD_1
        defaultEnfantShouldBeFound("field1.equals=" + DEFAULT_FIELD_1);

        // Get all the enfantList where field1 equals to UPDATED_FIELD_1
        defaultEnfantShouldNotBeFound("field1.equals=" + UPDATED_FIELD_1);
    }

    @Test
    @Transactional
    public void getAllEnfantsByField1IsInShouldWork() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where field1 in DEFAULT_FIELD_1 or UPDATED_FIELD_1
        defaultEnfantShouldBeFound("field1.in=" + DEFAULT_FIELD_1 + "," + UPDATED_FIELD_1);

        // Get all the enfantList where field1 equals to UPDATED_FIELD_1
        defaultEnfantShouldNotBeFound("field1.in=" + UPDATED_FIELD_1);
    }

    @Test
    @Transactional
    public void getAllEnfantsByField1IsNullOrNotNull() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where field1 is not null
        defaultEnfantShouldBeFound("field1.specified=true");

        // Get all the enfantList where field1 is null
        defaultEnfantShouldNotBeFound("field1.specified=false");
    }

    @Test
    @Transactional
    public void getAllEnfantsByField1IsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where field1 greater than or equals to DEFAULT_FIELD_1
        defaultEnfantShouldBeFound("field1.greaterOrEqualThan=" + DEFAULT_FIELD_1);

        // Get all the enfantList where field1 greater than or equals to UPDATED_FIELD_1
        defaultEnfantShouldNotBeFound("field1.greaterOrEqualThan=" + UPDATED_FIELD_1);
    }

    @Test
    @Transactional
    public void getAllEnfantsByField1IsLessThanSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where field1 less than or equals to DEFAULT_FIELD_1
        defaultEnfantShouldNotBeFound("field1.lessThan=" + DEFAULT_FIELD_1);

        // Get all the enfantList where field1 less than or equals to UPDATED_FIELD_1
        defaultEnfantShouldBeFound("field1.lessThan=" + UPDATED_FIELD_1);
    }


    @Test
    @Transactional
    public void getAllEnfantsByField2IsEqualToSomething() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where field2 equals to DEFAULT_FIELD_2
        defaultEnfantShouldBeFound("field2.equals=" + DEFAULT_FIELD_2);

        // Get all the enfantList where field2 equals to UPDATED_FIELD_2
        defaultEnfantShouldNotBeFound("field2.equals=" + UPDATED_FIELD_2);
    }

    @Test
    @Transactional
    public void getAllEnfantsByField2IsInShouldWork() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where field2 in DEFAULT_FIELD_2 or UPDATED_FIELD_2
        defaultEnfantShouldBeFound("field2.in=" + DEFAULT_FIELD_2 + "," + UPDATED_FIELD_2);

        // Get all the enfantList where field2 equals to UPDATED_FIELD_2
        defaultEnfantShouldNotBeFound("field2.in=" + UPDATED_FIELD_2);
    }

    @Test
    @Transactional
    public void getAllEnfantsByField2IsNullOrNotNull() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);

        // Get all the enfantList where field2 is not null
        defaultEnfantShouldBeFound("field2.specified=true");

        // Get all the enfantList where field2 is null
        defaultEnfantShouldNotBeFound("field2.specified=false");
    }

    @Test
    @Transactional
    public void getAllEnfantsByParentIsEqualToSomething() throws Exception {
        // Initialize the database
        Parent parent = ParentResourceIntTest.createEntity(em);
        em.persist(parent);
        em.flush();
        enfant.addParent(parent);
        enfantRepository.saveAndFlush(enfant);
        Long parentId = parent.getId();

        // Get all the enfantList where parent equals to parentId
        defaultEnfantShouldBeFound("parentId.equals=" + parentId);

        // Get all the enfantList where parent equals to parentId + 1
        defaultEnfantShouldNotBeFound("parentId.equals=" + (parentId + 1));
    }


    @Test
    @Transactional
    public void getAllEnfantsByParent1IsEqualToSomething() throws Exception {
        // Initialize the database
        Parent parent1 = ParentResourceIntTest.createEntity(em);
        em.persist(parent1);
        em.flush();
        enfant.setParent1(parent1);
        enfantRepository.saveAndFlush(enfant);
        Long parent1Id = parent1.getId();

        // Get all the enfantList where parent1 equals to parent1Id
        defaultEnfantShouldBeFound("parent1Id.equals=" + parent1Id);

        // Get all the enfantList where parent1 equals to parent1Id + 1
        defaultEnfantShouldNotBeFound("parent1Id.equals=" + (parent1Id + 1));
    }


    @Test
    @Transactional
    public void getAllEnfantsByParent2IsEqualToSomething() throws Exception {
        // Initialize the database
        Parent parent2 = ParentResourceIntTest.createEntity(em);
        em.persist(parent2);
        em.flush();
        enfant.setParent2(parent2);
        enfantRepository.saveAndFlush(enfant);
        Long parent2Id = parent2.getId();

        // Get all the enfantList where parent2 equals to parent2Id
        defaultEnfantShouldBeFound("parent2Id.equals=" + parent2Id);

        // Get all the enfantList where parent2 equals to parent2Id + 1
        defaultEnfantShouldNotBeFound("parent2Id.equals=" + (parent2Id + 1));
    }


    @Test
    @Transactional
    public void getAllEnfantsByParent3IsEqualToSomething() throws Exception {
        // Initialize the database
        Parent parent3 = ParentResourceIntTest.createEntity(em);
        em.persist(parent3);
        em.flush();
        enfant.setParent3(parent3);
        enfantRepository.saveAndFlush(enfant);
        Long parent3Id = parent3.getId();

        // Get all the enfantList where parent3 equals to parent3Id
        defaultEnfantShouldBeFound("parent3Id.equals=" + parent3Id);

        // Get all the enfantList where parent3 equals to parent3Id + 1
        defaultEnfantShouldNotBeFound("parent3Id.equals=" + (parent3Id + 1));
    }

    /**
     * Executes the search, and checks that the default entity is returned
     */
    private void defaultEnfantShouldBeFound(String filter) throws Exception {
        restEnfantMockMvc.perform(get("/api/enfants?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(enfant.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].age").value(hasItem(DEFAULT_AGE)))
            .andExpect(jsonPath("$.[*].quartier").value(hasItem(DEFAULT_QUARTIER.toString())))
            .andExpect(jsonPath("$.[*].dateNaiss").value(hasItem(sameInstant(DEFAULT_DATE_NAISS))))
            .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE.toString())))
            .andExpect(jsonPath("$.[*].enabled").value(hasItem(DEFAULT_ENABLED.booleanValue())))
            .andExpect(jsonPath("$.[*].field0").value(hasItem(DEFAULT_FIELD_0.doubleValue())))
            .andExpect(jsonPath("$.[*].field1").value(hasItem(DEFAULT_FIELD_1.intValue())))
            .andExpect(jsonPath("$.[*].field2").value(hasItem(DEFAULT_FIELD_2.toString())));
    }

    /**
     * Executes the search, and checks that the default entity is not returned
     */
    private void defaultEnfantShouldNotBeFound(String filter) throws Exception {
        restEnfantMockMvc.perform(get("/api/enfants?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$").isArray())
            .andExpect(jsonPath("$").isEmpty());
    }


    @Test
    @Transactional
    public void getNonExistingEnfant() throws Exception {
        // Get the enfant
        restEnfantMockMvc.perform(get("/api/enfants/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateEnfant() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);
        int databaseSizeBeforeUpdate = enfantRepository.findAll().size();

        // Update the enfant
        Enfant updatedEnfant = enfantRepository.findOne(enfant.getId());
        // Disconnect from session so that the updates on updatedEnfant are not directly saved in db
        em.detach(updatedEnfant);
        updatedEnfant
            .name(UPDATED_NAME)
            .age(UPDATED_AGE)
            .quartier(UPDATED_QUARTIER)
            .dateNaiss(UPDATED_DATE_NAISS)
            .type(UPDATED_TYPE)
            .enabled(UPDATED_ENABLED)
            .field0(UPDATED_FIELD_0)
            .field1(UPDATED_FIELD_1)
            .field2(UPDATED_FIELD_2);
        EnfantDTO enfantDTO = enfantMapper.toDto(updatedEnfant);

        restEnfantMockMvc.perform(put("/api/enfants")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(enfantDTO)))
            .andExpect(status().isOk());

        // Validate the Enfant in the database
        List<Enfant> enfantList = enfantRepository.findAll();
        assertThat(enfantList).hasSize(databaseSizeBeforeUpdate);
        Enfant testEnfant = enfantList.get(enfantList.size() - 1);
        assertThat(testEnfant.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testEnfant.getAge()).isEqualTo(UPDATED_AGE);
        assertThat(testEnfant.getQuartier()).isEqualTo(UPDATED_QUARTIER);
        assertThat(testEnfant.getDateNaiss()).isEqualTo(UPDATED_DATE_NAISS);
        assertThat(testEnfant.getType()).isEqualTo(UPDATED_TYPE);
        assertThat(testEnfant.isEnabled()).isEqualTo(UPDATED_ENABLED);
        assertThat(testEnfant.getField0()).isEqualTo(UPDATED_FIELD_0);
        assertThat(testEnfant.getField1()).isEqualTo(UPDATED_FIELD_1);
        assertThat(testEnfant.getField2()).isEqualTo(UPDATED_FIELD_2);
    }

    @Test
    @Transactional
    public void updateNonExistingEnfant() throws Exception {
        int databaseSizeBeforeUpdate = enfantRepository.findAll().size();

        // Create the Enfant
        EnfantDTO enfantDTO = enfantMapper.toDto(enfant);

        // If the entity doesn't have an ID, it will be created instead of just being updated
        restEnfantMockMvc.perform(put("/api/enfants")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(enfantDTO)))
            .andExpect(status().isCreated());

        // Validate the Enfant in the database
        List<Enfant> enfantList = enfantRepository.findAll();
        assertThat(enfantList).hasSize(databaseSizeBeforeUpdate + 1);
    }

    @Test
    @Transactional
    public void deleteEnfant() throws Exception {
        // Initialize the database
        enfantRepository.saveAndFlush(enfant);
        int databaseSizeBeforeDelete = enfantRepository.findAll().size();

        // Get the enfant
        restEnfantMockMvc.perform(delete("/api/enfants/{id}", enfant.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Enfant> enfantList = enfantRepository.findAll();
        assertThat(enfantList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Enfant.class);
        Enfant enfant1 = new Enfant();
        enfant1.setId(1L);
        Enfant enfant2 = new Enfant();
        enfant2.setId(enfant1.getId());
        assertThat(enfant1).isEqualTo(enfant2);
        enfant2.setId(2L);
        assertThat(enfant1).isNotEqualTo(enfant2);
        enfant1.setId(null);
        assertThat(enfant1).isNotEqualTo(enfant2);
    }

    @Test
    @Transactional
    public void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(EnfantDTO.class);
        EnfantDTO enfantDTO1 = new EnfantDTO();
        enfantDTO1.setId(1L);
        EnfantDTO enfantDTO2 = new EnfantDTO();
        assertThat(enfantDTO1).isNotEqualTo(enfantDTO2);
        enfantDTO2.setId(enfantDTO1.getId());
        assertThat(enfantDTO1).isEqualTo(enfantDTO2);
        enfantDTO2.setId(2L);
        assertThat(enfantDTO1).isNotEqualTo(enfantDTO2);
        enfantDTO1.setId(null);
        assertThat(enfantDTO1).isNotEqualTo(enfantDTO2);
    }

    @Test
    @Transactional
    public void testEntityFromId() {
        assertThat(enfantMapper.fromId(42L).getId()).isEqualTo(42);
        assertThat(enfantMapper.fromId(null)).isNull();
    }
}
