package com.tradeprocess.admin.service.mapper;

import com.tradeprocess.admin.domain.*;
import com.tradeprocess.admin.service.dto.ParentDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Parent and its DTO ParentDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface ParentMapper extends EntityMapper<ParentDTO, Parent> {



    default Parent fromId(Long id) {
        if (id == null) {
            return null;
        }
        Parent parent = new Parent();
        parent.setId(id);
        return parent;
    }
}
