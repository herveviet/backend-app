package com.tradeprocess.admin.service.dto;


import java.time.Instant;
import java.time.ZonedDateTime;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;
import com.tradeprocess.admin.domain.enumeration.Type;

/**
 * A DTO for the Enfant entity.
 */
public class EnfantDTO implements Serializable {

    private Long id;

    private String name;

    private Integer age;

    private String quartier;

    private ZonedDateTime dateNaiss;

    private Type type;

    private Boolean enabled;

    private Float field0;

    private Long field1;

    private Instant field2;

    private Long parent1Id;

    private Long parent2Id;

    private Long parent3Id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getQuartier() {
        return quartier;
    }

    public void setQuartier(String quartier) {
        this.quartier = quartier;
    }

    public ZonedDateTime getDateNaiss() {
        return dateNaiss;
    }

    public void setDateNaiss(ZonedDateTime dateNaiss) {
        this.dateNaiss = dateNaiss;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public Boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public Float getField0() {
        return field0;
    }

    public void setField0(Float field0) {
        this.field0 = field0;
    }

    public Long getField1() {
        return field1;
    }

    public void setField1(Long field1) {
        this.field1 = field1;
    }

    public Instant getField2() {
        return field2;
    }

    public void setField2(Instant field2) {
        this.field2 = field2;
    }

    public Long getParent1Id() {
        return parent1Id;
    }

    public void setParent1Id(Long parentId) {
        this.parent1Id = parentId;
    }

    public Long getParent2Id() {
        return parent2Id;
    }

    public void setParent2Id(Long parentId) {
        this.parent2Id = parentId;
    }

    public Long getParent3Id() {
        return parent3Id;
    }

    public void setParent3Id(Long parentId) {
        this.parent3Id = parentId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        EnfantDTO enfantDTO = (EnfantDTO) o;
        if(enfantDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), enfantDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "EnfantDTO{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", age=" + getAge() +
            ", quartier='" + getQuartier() + "'" +
            ", dateNaiss='" + getDateNaiss() + "'" +
            ", type='" + getType() + "'" +
            ", enabled='" + isEnabled() + "'" +
            ", field0=" + getField0() +
            ", field1=" + getField1() +
            ", field2='" + getField2() + "'" +
            "}";
    }
}
