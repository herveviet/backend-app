package com.tradeprocess.admin.service;


import java.time.ZonedDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import io.github.jhipster.service.QueryService;

import com.tradeprocess.admin.domain.Enfant;
import com.tradeprocess.admin.domain.*; // for static metamodels
import com.tradeprocess.admin.repository.EnfantRepository;
import com.tradeprocess.admin.service.dto.EnfantCriteria;

import com.tradeprocess.admin.service.dto.EnfantDTO;
import com.tradeprocess.admin.service.mapper.EnfantMapper;
import com.tradeprocess.admin.domain.enumeration.Type;

/**
 * Service for executing complex queries for Enfant entities in the database.
 * The main input is a {@link EnfantCriteria} which get's converted to {@link Specifications},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link EnfantDTO} or a {@link Page} of {@link EnfantDTO} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class EnfantQueryService extends QueryService<Enfant> {

    private final Logger log = LoggerFactory.getLogger(EnfantQueryService.class);


    private final EnfantRepository enfantRepository;

    private final EnfantMapper enfantMapper;

    public EnfantQueryService(EnfantRepository enfantRepository, EnfantMapper enfantMapper) {
        this.enfantRepository = enfantRepository;
        this.enfantMapper = enfantMapper;
    }

    /**
     * Return a {@link List} of {@link EnfantDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public List<EnfantDTO> findByCriteria(EnfantCriteria criteria) {
        log.debug("find by criteria : {}", criteria);
        final Specifications<Enfant> specification = createSpecification(criteria);
        return enfantMapper.toDto(enfantRepository.findAll(specification));
    }

    /**
     * Return a {@link Page} of {@link EnfantDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @param page The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<EnfantDTO> findByCriteria(EnfantCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specifications<Enfant> specification = createSpecification(criteria);
        final Page<Enfant> result = enfantRepository.findAll(specification, page);
        return result.map(enfantMapper::toDto);
    }

    /**
     * Function to convert EnfantCriteria to a {@link Specifications}
     */
    private Specifications<Enfant> createSpecification(EnfantCriteria criteria) {
        Specifications<Enfant> specification = Specifications.where(null);
        if (criteria != null) {
            if (criteria.getId() != null) {
                specification = specification.and(buildSpecification(criteria.getId(), Enfant_.id));
            }
            if (criteria.getName() != null) {
                specification = specification.and(buildStringSpecification(criteria.getName(), Enfant_.name));
            }
            if (criteria.getAge() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getAge(), Enfant_.age));
            }
            if (criteria.getQuartier() != null) {
                specification = specification.and(buildStringSpecification(criteria.getQuartier(), Enfant_.quartier));
            }
            if (criteria.getDateNaiss() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getDateNaiss(), Enfant_.dateNaiss));
            }
            if (criteria.getType() != null) {
                specification = specification.and(buildSpecification(criteria.getType(), Enfant_.type));
            }
            if (criteria.getEnabled() != null) {
                specification = specification.and(buildSpecification(criteria.getEnabled(), Enfant_.enabled));
            }
            if (criteria.getField0() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getField0(), Enfant_.field0));
            }
            if (criteria.getField1() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getField1(), Enfant_.field1));
            }
            if (criteria.getField2() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getField2(), Enfant_.field2));
            }
            if (criteria.getParentId() != null) {
                specification = specification.and(buildReferringEntitySpecification(criteria.getParentId(), Enfant_.parents, Parent_.id));
            }
            if (criteria.getParent1Id() != null) {
                specification = specification.and(buildReferringEntitySpecification(criteria.getParent1Id(), Enfant_.parent1, Parent_.id));
            }
            if (criteria.getParent2Id() != null) {
                specification = specification.and(buildReferringEntitySpecification(criteria.getParent2Id(), Enfant_.parent2, Parent_.id));
            }
            if (criteria.getParent3Id() != null) {
                specification = specification.and(buildReferringEntitySpecification(criteria.getParent3Id(), Enfant_.parent3, Parent_.id));
            }
        }
        return specification;
    }

}
