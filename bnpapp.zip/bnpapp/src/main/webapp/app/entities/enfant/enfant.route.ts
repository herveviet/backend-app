import { Routes } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { EnfantComponent } from './enfant.component';
import { EnfantDetailComponent } from './enfant-detail.component';
import { EnfantPopupComponent } from './enfant-dialog.component';
import { EnfantDeletePopupComponent } from './enfant-delete-dialog.component';

export const enfantRoute: Routes = [
    {
        path: 'enfant',
        component: EnfantComponent,
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'tradeprocessadminApp.enfant.home.title'
        },
        canActivate: [UserRouteAccessService]
    }, {
        path: 'enfant/:id',
        component: EnfantDetailComponent,
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'tradeprocessadminApp.enfant.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];

export const enfantPopupRoute: Routes = [
    {
        path: 'enfant-new',
        component: EnfantPopupComponent,
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'tradeprocessadminApp.enfant.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    },
    {
        path: 'enfant/:id/edit',
        component: EnfantPopupComponent,
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'tradeprocessadminApp.enfant.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    },
    {
        path: 'enfant/:id/delete',
        component: EnfantDeletePopupComponent,
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'tradeprocessadminApp.enfant.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    }
];
