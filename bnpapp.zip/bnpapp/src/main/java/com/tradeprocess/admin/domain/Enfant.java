package com.tradeprocess.admin.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

import java.io.Serializable;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

import com.tradeprocess.admin.domain.enumeration.Type;

/**
 * A Enfant.
 */
@Entity
@Table(name = "enfant")
public class Enfant implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "age")
    private Integer age;

    @Column(name = "quartier")
    private String quartier;

    @Column(name = "date_naiss")
    private ZonedDateTime dateNaiss;

    @Enumerated(EnumType.STRING)
    @Column(name = "jhi_type")
    private Type type;

    @Column(name = "enabled")
    private Boolean enabled;

    @Column(name = "field_0")
    private Float field0;

    @Column(name = "field_1")
    private Long field1;

    @Column(name = "field_2")
    private Instant field2;

    @OneToMany(mappedBy = "enfant")
    @JsonIgnore
    private Set<Parent> parents = new HashSet<>();

    @ManyToOne
    private Parent parent1;

    @ManyToOne
    private Parent parent2;

    @ManyToOne
    private Parent parent3;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public Enfant name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public Enfant age(Integer age) {
        this.age = age;
        return this;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getQuartier() {
        return quartier;
    }

    public Enfant quartier(String quartier) {
        this.quartier = quartier;
        return this;
    }

    public void setQuartier(String quartier) {
        this.quartier = quartier;
    }

    public ZonedDateTime getDateNaiss() {
        return dateNaiss;
    }

    public Enfant dateNaiss(ZonedDateTime dateNaiss) {
        this.dateNaiss = dateNaiss;
        return this;
    }

    public void setDateNaiss(ZonedDateTime dateNaiss) {
        this.dateNaiss = dateNaiss;
    }

    public Type getType() {
        return type;
    }

    public Enfant type(Type type) {
        this.type = type;
        return this;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public Boolean isEnabled() {
        return enabled;
    }

    public Enfant enabled(Boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public Float getField0() {
        return field0;
    }

    public Enfant field0(Float field0) {
        this.field0 = field0;
        return this;
    }

    public void setField0(Float field0) {
        this.field0 = field0;
    }

    public Long getField1() {
        return field1;
    }

    public Enfant field1(Long field1) {
        this.field1 = field1;
        return this;
    }

    public void setField1(Long field1) {
        this.field1 = field1;
    }

    public Instant getField2() {
        return field2;
    }

    public Enfant field2(Instant field2) {
        this.field2 = field2;
        return this;
    }

    public void setField2(Instant field2) {
        this.field2 = field2;
    }

    public Set<Parent> getParents() {
        return parents;
    }

    public Enfant parents(Set<Parent> parents) {
        this.parents = parents;
        return this;
    }

    public Enfant addParent(Parent parent) {
        this.parents.add(parent);
        parent.setEnfant(this);
        return this;
    }

    public Enfant removeParent(Parent parent) {
        this.parents.remove(parent);
        parent.setEnfant(null);
        return this;
    }

    public void setParents(Set<Parent> parents) {
        this.parents = parents;
    }

    public Parent getParent1() {
        return parent1;
    }

    public Enfant parent1(Parent parent) {
        this.parent1 = parent;
        return this;
    }

    public void setParent1(Parent parent) {
        this.parent1 = parent;
    }

    public Parent getParent2() {
        return parent2;
    }

    public Enfant parent2(Parent parent) {
        this.parent2 = parent;
        return this;
    }

    public void setParent2(Parent parent) {
        this.parent2 = parent;
    }

    public Parent getParent3() {
        return parent3;
    }

    public Enfant parent3(Parent parent) {
        this.parent3 = parent;
        return this;
    }

    public void setParent3(Parent parent) {
        this.parent3 = parent;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Enfant enfant = (Enfant) o;
        if (enfant.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), enfant.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Enfant{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", age=" + getAge() +
            ", quartier='" + getQuartier() + "'" +
            ", dateNaiss='" + getDateNaiss() + "'" +
            ", type='" + getType() + "'" +
            ", enabled='" + isEnabled() + "'" +
            ", field0=" + getField0() +
            ", field1=" + getField1() +
            ", field2='" + getField2() + "'" +
            "}";
    }
}
