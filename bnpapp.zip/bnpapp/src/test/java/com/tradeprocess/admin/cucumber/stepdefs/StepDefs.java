package com.tradeprocess.admin.cucumber.stepdefs;

import com.tradeprocess.admin.TradeprocessadminApp;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.ResultActions;

import org.springframework.boot.test.context.SpringBootTest;

@WebAppConfiguration
@SpringBootTest
@ContextConfiguration(classes = TradeprocessadminApp.class)
public abstract class StepDefs {

    protected ResultActions actions;

}
