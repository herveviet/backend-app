/**
 * JPA domain objects.
 */
package com.tradeprocess.admin.domain;
