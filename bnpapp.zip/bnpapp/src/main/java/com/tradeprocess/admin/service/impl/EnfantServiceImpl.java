package com.tradeprocess.admin.service.impl;

import com.tradeprocess.admin.service.EnfantService;
import com.tradeprocess.admin.domain.Enfant;
import com.tradeprocess.admin.repository.EnfantRepository;
import com.tradeprocess.admin.service.dto.EnfantDTO;
import com.tradeprocess.admin.service.mapper.EnfantMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * Service Implementation for managing Enfant.
 */
@Service
@Transactional
public class EnfantServiceImpl implements EnfantService {

    private final Logger log = LoggerFactory.getLogger(EnfantServiceImpl.class);

    private final EnfantRepository enfantRepository;

    private final EnfantMapper enfantMapper;

    public EnfantServiceImpl(EnfantRepository enfantRepository, EnfantMapper enfantMapper) {
        this.enfantRepository = enfantRepository;
        this.enfantMapper = enfantMapper;
    }

    /**
     * Save a enfant.
     *
     * @param enfantDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public EnfantDTO save(EnfantDTO enfantDTO) {
        log.debug("Request to save Enfant : {}", enfantDTO);
        Enfant enfant = enfantMapper.toEntity(enfantDTO);
        enfant = enfantRepository.save(enfant);
        return enfantMapper.toDto(enfant);
    }

    /**
     * Get all the enfants.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<EnfantDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Enfants");
        return enfantRepository.findAll(pageable)
            .map(enfantMapper::toDto);
    }

    /**
     * Get one enfant by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public EnfantDTO findOne(Long id) {
        log.debug("Request to get Enfant : {}", id);
        Enfant enfant = enfantRepository.findOne(id);
        return enfantMapper.toDto(enfant);
    }

    /**
     * Delete the enfant by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete Enfant : {}", id);
        enfantRepository.delete(id);
    }
}
