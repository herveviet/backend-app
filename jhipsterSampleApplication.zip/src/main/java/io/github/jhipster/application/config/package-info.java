/**
 * Spring Framework configuration files.
 */
package io.github.jhipster.application.config;
