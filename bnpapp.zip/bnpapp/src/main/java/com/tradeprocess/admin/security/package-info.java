/**
 * Spring Security configuration.
 */
package com.tradeprocess.admin.security;
