package com.tradeprocess.admin.service.dto;

import java.io.Serializable;
import com.tradeprocess.admin.domain.enumeration.Type;
import io.github.jhipster.service.filter.BooleanFilter;
import io.github.jhipster.service.filter.DoubleFilter;
import io.github.jhipster.service.filter.Filter;
import io.github.jhipster.service.filter.FloatFilter;
import io.github.jhipster.service.filter.IntegerFilter;
import io.github.jhipster.service.filter.LongFilter;
import io.github.jhipster.service.filter.StringFilter;

import io.github.jhipster.service.filter.InstantFilter;

import io.github.jhipster.service.filter.ZonedDateTimeFilter;


/**
 * Criteria class for the Enfant entity. This class is used in EnfantResource to
 * receive all the possible filtering options from the Http GET request parameters.
 * For example the following could be a valid requests:
 * <code> /enfants?id.greaterThan=5&amp;attr1.contains=something&amp;attr2.specified=false</code>
 * As Spring is unable to properly convert the types, unless specific {@link Filter} class are used, we need to use
 * fix type specific filters.
 */
public class EnfantCriteria implements Serializable {
    /**
     * Class for filtering Type
     */
    public static class TypeFilter extends Filter<Type> {
    }

    private static final long serialVersionUID = 1L;


    private LongFilter id;

    private StringFilter name;

    private IntegerFilter age;

    private StringFilter quartier;

    private ZonedDateTimeFilter dateNaiss;

    private TypeFilter type;

    private BooleanFilter enabled;

    private FloatFilter field0;

    private LongFilter field1;

    private InstantFilter field2;

    private LongFilter parentId;

    private LongFilter parent1Id;

    private LongFilter parent2Id;

    private LongFilter parent3Id;

    public EnfantCriteria() {
    }

    public LongFilter getId() {
        return id;
    }

    public void setId(LongFilter id) {
        this.id = id;
    }

    public StringFilter getName() {
        return name;
    }

    public void setName(StringFilter name) {
        this.name = name;
    }

    public IntegerFilter getAge() {
        return age;
    }

    public void setAge(IntegerFilter age) {
        this.age = age;
    }

    public StringFilter getQuartier() {
        return quartier;
    }

    public void setQuartier(StringFilter quartier) {
        this.quartier = quartier;
    }

    public ZonedDateTimeFilter getDateNaiss() {
        return dateNaiss;
    }

    public void setDateNaiss(ZonedDateTimeFilter dateNaiss) {
        this.dateNaiss = dateNaiss;
    }

    public TypeFilter getType() {
        return type;
    }

    public void setType(TypeFilter type) {
        this.type = type;
    }

    public BooleanFilter getEnabled() {
        return enabled;
    }

    public void setEnabled(BooleanFilter enabled) {
        this.enabled = enabled;
    }

    public FloatFilter getField0() {
        return field0;
    }

    public void setField0(FloatFilter field0) {
        this.field0 = field0;
    }

    public LongFilter getField1() {
        return field1;
    }

    public void setField1(LongFilter field1) {
        this.field1 = field1;
    }

    public InstantFilter getField2() {
        return field2;
    }

    public void setField2(InstantFilter field2) {
        this.field2 = field2;
    }

    public LongFilter getParentId() {
        return parentId;
    }

    public void setParentId(LongFilter parentId) {
        this.parentId = parentId;
    }

    public LongFilter getParent1Id() {
        return parent1Id;
    }

    public void setParent1Id(LongFilter parent1Id) {
        this.parent1Id = parent1Id;
    }

    public LongFilter getParent2Id() {
        return parent2Id;
    }

    public void setParent2Id(LongFilter parent2Id) {
        this.parent2Id = parent2Id;
    }

    public LongFilter getParent3Id() {
        return parent3Id;
    }

    public void setParent3Id(LongFilter parent3Id) {
        this.parent3Id = parent3Id;
    }

    @Override
    public String toString() {
        return "EnfantCriteria{" +
                (id != null ? "id=" + id + ", " : "") +
                (name != null ? "name=" + name + ", " : "") +
                (age != null ? "age=" + age + ", " : "") +
                (quartier != null ? "quartier=" + quartier + ", " : "") +
                (dateNaiss != null ? "dateNaiss=" + dateNaiss + ", " : "") +
                (type != null ? "type=" + type + ", " : "") +
                (enabled != null ? "enabled=" + enabled + ", " : "") +
                (field0 != null ? "field0=" + field0 + ", " : "") +
                (field1 != null ? "field1=" + field1 + ", " : "") +
                (field2 != null ? "field2=" + field2 + ", " : "") +
                (parentId != null ? "parentId=" + parentId + ", " : "") +
                (parent1Id != null ? "parent1Id=" + parent1Id + ", " : "") +
                (parent2Id != null ? "parent2Id=" + parent2Id + ", " : "") +
                (parent3Id != null ? "parent3Id=" + parent3Id + ", " : "") +
            "}";
    }

}
