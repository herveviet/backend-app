/**
 * Spring Data JPA repositories.
 */
package com.tradeprocess.admin.repository;
