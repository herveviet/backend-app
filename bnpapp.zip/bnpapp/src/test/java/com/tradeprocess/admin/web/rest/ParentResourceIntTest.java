package com.tradeprocess.admin.web.rest;

import com.tradeprocess.admin.TradeprocessadminApp;

import com.tradeprocess.admin.domain.Parent;
import com.tradeprocess.admin.repository.ParentRepository;
import com.tradeprocess.admin.service.ParentService;
import com.tradeprocess.admin.service.dto.ParentDTO;
import com.tradeprocess.admin.service.mapper.ParentMapper;
import com.tradeprocess.admin.web.rest.errors.ExceptionTranslator;
import com.tradeprocess.admin.service.dto.ParentCriteria;
import com.tradeprocess.admin.service.ParentQueryService;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.util.List;

import static com.tradeprocess.admin.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the ParentResource REST controller.
 *
 * @see ParentResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TradeprocessadminApp.class)
public class ParentResourceIntTest {

    private static final String DEFAULT_NAME = "AAAAAAAAAA";
    private static final String UPDATED_NAME = "BBBBBBBBBB";

    private static final Integer DEFAULT_AGE = 1;
    private static final Integer UPDATED_AGE = 2;

    private static final String DEFAULT_FONCTION = "AAAAAAAAAA";
    private static final String UPDATED_FONCTION = "BBBBBBBBBB";

    @Autowired
    private ParentRepository parentRepository;

    @Autowired
    private ParentMapper parentMapper;

    @Autowired
    private ParentService parentService;

    @Autowired
    private ParentQueryService parentQueryService;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    private MockMvc restParentMockMvc;

    private Parent parent;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final ParentResource parentResource = new ParentResource(parentService, parentQueryService);
        this.restParentMockMvc = MockMvcBuilders.standaloneSetup(parentResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Parent createEntity(EntityManager em) {
        Parent parent = new Parent()
            .name(DEFAULT_NAME)
            .age(DEFAULT_AGE)
            .fonction(DEFAULT_FONCTION);
        return parent;
    }

    @Before
    public void initTest() {
        parent = createEntity(em);
    }

    @Test
    @Transactional
    public void createParent() throws Exception {
        int databaseSizeBeforeCreate = parentRepository.findAll().size();

        // Create the Parent
        ParentDTO parentDTO = parentMapper.toDto(parent);
        restParentMockMvc.perform(post("/api/parents")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(parentDTO)))
            .andExpect(status().isCreated());

        // Validate the Parent in the database
        List<Parent> parentList = parentRepository.findAll();
        assertThat(parentList).hasSize(databaseSizeBeforeCreate + 1);
        Parent testParent = parentList.get(parentList.size() - 1);
        assertThat(testParent.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testParent.getAge()).isEqualTo(DEFAULT_AGE);
        assertThat(testParent.getFonction()).isEqualTo(DEFAULT_FONCTION);
    }

    @Test
    @Transactional
    public void createParentWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = parentRepository.findAll().size();

        // Create the Parent with an existing ID
        parent.setId(1L);
        ParentDTO parentDTO = parentMapper.toDto(parent);

        // An entity with an existing ID cannot be created, so this API call must fail
        restParentMockMvc.perform(post("/api/parents")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(parentDTO)))
            .andExpect(status().isBadRequest());

        // Validate the Parent in the database
        List<Parent> parentList = parentRepository.findAll();
        assertThat(parentList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void getAllParents() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);

        // Get all the parentList
        restParentMockMvc.perform(get("/api/parents?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(parent.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].age").value(hasItem(DEFAULT_AGE)))
            .andExpect(jsonPath("$.[*].fonction").value(hasItem(DEFAULT_FONCTION.toString())));
    }

    @Test
    @Transactional
    public void getParent() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);

        // Get the parent
        restParentMockMvc.perform(get("/api/parents/{id}", parent.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(parent.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.age").value(DEFAULT_AGE))
            .andExpect(jsonPath("$.fonction").value(DEFAULT_FONCTION.toString()));
    }

    @Test
    @Transactional
    public void getAllParentsByNameIsEqualToSomething() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);

        // Get all the parentList where name equals to DEFAULT_NAME
        defaultParentShouldBeFound("name.equals=" + DEFAULT_NAME);

        // Get all the parentList where name equals to UPDATED_NAME
        defaultParentShouldNotBeFound("name.equals=" + UPDATED_NAME);
    }

    @Test
    @Transactional
    public void getAllParentsByNameIsInShouldWork() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);

        // Get all the parentList where name in DEFAULT_NAME or UPDATED_NAME
        defaultParentShouldBeFound("name.in=" + DEFAULT_NAME + "," + UPDATED_NAME);

        // Get all the parentList where name equals to UPDATED_NAME
        defaultParentShouldNotBeFound("name.in=" + UPDATED_NAME);
    }

    @Test
    @Transactional
    public void getAllParentsByNameIsNullOrNotNull() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);

        // Get all the parentList where name is not null
        defaultParentShouldBeFound("name.specified=true");

        // Get all the parentList where name is null
        defaultParentShouldNotBeFound("name.specified=false");
    }

    @Test
    @Transactional
    public void getAllParentsByAgeIsEqualToSomething() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);

        // Get all the parentList where age equals to DEFAULT_AGE
        defaultParentShouldBeFound("age.equals=" + DEFAULT_AGE);

        // Get all the parentList where age equals to UPDATED_AGE
        defaultParentShouldNotBeFound("age.equals=" + UPDATED_AGE);
    }

    @Test
    @Transactional
    public void getAllParentsByAgeIsInShouldWork() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);

        // Get all the parentList where age in DEFAULT_AGE or UPDATED_AGE
        defaultParentShouldBeFound("age.in=" + DEFAULT_AGE + "," + UPDATED_AGE);

        // Get all the parentList where age equals to UPDATED_AGE
        defaultParentShouldNotBeFound("age.in=" + UPDATED_AGE);
    }

    @Test
    @Transactional
    public void getAllParentsByAgeIsNullOrNotNull() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);

        // Get all the parentList where age is not null
        defaultParentShouldBeFound("age.specified=true");

        // Get all the parentList where age is null
        defaultParentShouldNotBeFound("age.specified=false");
    }

    @Test
    @Transactional
    public void getAllParentsByAgeIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);

        // Get all the parentList where age greater than or equals to DEFAULT_AGE
        defaultParentShouldBeFound("age.greaterOrEqualThan=" + DEFAULT_AGE);

        // Get all the parentList where age greater than or equals to UPDATED_AGE
        defaultParentShouldNotBeFound("age.greaterOrEqualThan=" + UPDATED_AGE);
    }

    @Test
    @Transactional
    public void getAllParentsByAgeIsLessThanSomething() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);

        // Get all the parentList where age less than or equals to DEFAULT_AGE
        defaultParentShouldNotBeFound("age.lessThan=" + DEFAULT_AGE);

        // Get all the parentList where age less than or equals to UPDATED_AGE
        defaultParentShouldBeFound("age.lessThan=" + UPDATED_AGE);
    }


    @Test
    @Transactional
    public void getAllParentsByFonctionIsEqualToSomething() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);

        // Get all the parentList where fonction equals to DEFAULT_FONCTION
        defaultParentShouldBeFound("fonction.equals=" + DEFAULT_FONCTION);

        // Get all the parentList where fonction equals to UPDATED_FONCTION
        defaultParentShouldNotBeFound("fonction.equals=" + UPDATED_FONCTION);
    }

    @Test
    @Transactional
    public void getAllParentsByFonctionIsInShouldWork() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);

        // Get all the parentList where fonction in DEFAULT_FONCTION or UPDATED_FONCTION
        defaultParentShouldBeFound("fonction.in=" + DEFAULT_FONCTION + "," + UPDATED_FONCTION);

        // Get all the parentList where fonction equals to UPDATED_FONCTION
        defaultParentShouldNotBeFound("fonction.in=" + UPDATED_FONCTION);
    }

    @Test
    @Transactional
    public void getAllParentsByFonctionIsNullOrNotNull() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);

        // Get all the parentList where fonction is not null
        defaultParentShouldBeFound("fonction.specified=true");

        // Get all the parentList where fonction is null
        defaultParentShouldNotBeFound("fonction.specified=false");
    }
    /**
     * Executes the search, and checks that the default entity is returned
     */
    private void defaultParentShouldBeFound(String filter) throws Exception {
        restParentMockMvc.perform(get("/api/parents?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(parent.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].age").value(hasItem(DEFAULT_AGE)))
            .andExpect(jsonPath("$.[*].fonction").value(hasItem(DEFAULT_FONCTION.toString())));
    }

    /**
     * Executes the search, and checks that the default entity is not returned
     */
    private void defaultParentShouldNotBeFound(String filter) throws Exception {
        restParentMockMvc.perform(get("/api/parents?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$").isArray())
            .andExpect(jsonPath("$").isEmpty());
    }


    @Test
    @Transactional
    public void getNonExistingParent() throws Exception {
        // Get the parent
        restParentMockMvc.perform(get("/api/parents/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateParent() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);
        int databaseSizeBeforeUpdate = parentRepository.findAll().size();

        // Update the parent
        Parent updatedParent = parentRepository.findOne(parent.getId());
        // Disconnect from session so that the updates on updatedParent are not directly saved in db
        em.detach(updatedParent);
        updatedParent
            .name(UPDATED_NAME)
            .age(UPDATED_AGE)
            .fonction(UPDATED_FONCTION);
        ParentDTO parentDTO = parentMapper.toDto(updatedParent);

        restParentMockMvc.perform(put("/api/parents")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(parentDTO)))
            .andExpect(status().isOk());

        // Validate the Parent in the database
        List<Parent> parentList = parentRepository.findAll();
        assertThat(parentList).hasSize(databaseSizeBeforeUpdate);
        Parent testParent = parentList.get(parentList.size() - 1);
        assertThat(testParent.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testParent.getAge()).isEqualTo(UPDATED_AGE);
        assertThat(testParent.getFonction()).isEqualTo(UPDATED_FONCTION);
    }

    @Test
    @Transactional
    public void updateNonExistingParent() throws Exception {
        int databaseSizeBeforeUpdate = parentRepository.findAll().size();

        // Create the Parent
        ParentDTO parentDTO = parentMapper.toDto(parent);

        // If the entity doesn't have an ID, it will be created instead of just being updated
        restParentMockMvc.perform(put("/api/parents")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(parentDTO)))
            .andExpect(status().isCreated());

        // Validate the Parent in the database
        List<Parent> parentList = parentRepository.findAll();
        assertThat(parentList).hasSize(databaseSizeBeforeUpdate + 1);
    }

    @Test
    @Transactional
    public void deleteParent() throws Exception {
        // Initialize the database
        parentRepository.saveAndFlush(parent);
        int databaseSizeBeforeDelete = parentRepository.findAll().size();

        // Get the parent
        restParentMockMvc.perform(delete("/api/parents/{id}", parent.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Parent> parentList = parentRepository.findAll();
        assertThat(parentList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Parent.class);
        Parent parent1 = new Parent();
        parent1.setId(1L);
        Parent parent2 = new Parent();
        parent2.setId(parent1.getId());
        assertThat(parent1).isEqualTo(parent2);
        parent2.setId(2L);
        assertThat(parent1).isNotEqualTo(parent2);
        parent1.setId(null);
        assertThat(parent1).isNotEqualTo(parent2);
    }

    @Test
    @Transactional
    public void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(ParentDTO.class);
        ParentDTO parentDTO1 = new ParentDTO();
        parentDTO1.setId(1L);
        ParentDTO parentDTO2 = new ParentDTO();
        assertThat(parentDTO1).isNotEqualTo(parentDTO2);
        parentDTO2.setId(parentDTO1.getId());
        assertThat(parentDTO1).isEqualTo(parentDTO2);
        parentDTO2.setId(2L);
        assertThat(parentDTO1).isNotEqualTo(parentDTO2);
        parentDTO1.setId(null);
        assertThat(parentDTO1).isNotEqualTo(parentDTO2);
    }

    @Test
    @Transactional
    public void testEntityFromId() {
        assertThat(parentMapper.fromId(42L).getId()).isEqualTo(42);
        assertThat(parentMapper.fromId(null)).isNull();
    }
}
