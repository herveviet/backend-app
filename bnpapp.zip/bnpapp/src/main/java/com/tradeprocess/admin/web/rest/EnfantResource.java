package com.tradeprocess.admin.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.tradeprocess.admin.service.EnfantService;
import com.tradeprocess.admin.web.rest.errors.BadRequestAlertException;
import com.tradeprocess.admin.web.rest.util.HeaderUtil;
import com.tradeprocess.admin.web.rest.util.PaginationUtil;
import com.tradeprocess.admin.service.dto.EnfantDTO;
import com.tradeprocess.admin.service.dto.EnfantCriteria;
import com.tradeprocess.admin.service.EnfantQueryService;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Enfant.
 */
@RestController
@RequestMapping("/api")
public class EnfantResource {

    private final Logger log = LoggerFactory.getLogger(EnfantResource.class);

    private static final String ENTITY_NAME = "enfant";

    private final EnfantService enfantService;

    private final EnfantQueryService enfantQueryService;

    public EnfantResource(EnfantService enfantService, EnfantQueryService enfantQueryService) {
        this.enfantService = enfantService;
        this.enfantQueryService = enfantQueryService;
    }

    /**
     * POST  /enfants : Create a new enfant.
     *
     * @param enfantDTO the enfantDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new enfantDTO, or with status 400 (Bad Request) if the enfant has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/enfants")
    @Timed
    public ResponseEntity<EnfantDTO> createEnfant(@RequestBody EnfantDTO enfantDTO) throws URISyntaxException {
        log.debug("REST request to save Enfant : {}", enfantDTO);
        if (enfantDTO.getId() != null) {
            throw new BadRequestAlertException("A new enfant cannot already have an ID", ENTITY_NAME, "idexists");
        }
        EnfantDTO result = enfantService.save(enfantDTO);
        return ResponseEntity.created(new URI("/api/enfants/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /enfants : Updates an existing enfant.
     *
     * @param enfantDTO the enfantDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated enfantDTO,
     * or with status 400 (Bad Request) if the enfantDTO is not valid,
     * or with status 500 (Internal Server Error) if the enfantDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/enfants")
    @Timed
    public ResponseEntity<EnfantDTO> updateEnfant(@RequestBody EnfantDTO enfantDTO) throws URISyntaxException {
        log.debug("REST request to update Enfant : {}", enfantDTO);
        if (enfantDTO.getId() == null) {
            return createEnfant(enfantDTO);
        }
        EnfantDTO result = enfantService.save(enfantDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, enfantDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /enfants : get all the enfants.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of enfants in body
     */
    @GetMapping("/enfants")
    @Timed
    public ResponseEntity<List<EnfantDTO>> getAllEnfants(EnfantCriteria criteria, Pageable pageable) {
        log.debug("REST request to get Enfants by criteria: {}", criteria);
        Page<EnfantDTO> page = enfantQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/enfants");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }

    /**
     * GET  /enfants/:id : get the "id" enfant.
     *
     * @param id the id of the enfantDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the enfantDTO, or with status 404 (Not Found)
     */
    @GetMapping("/enfants/{id}")
    @Timed
    public ResponseEntity<EnfantDTO> getEnfant(@PathVariable Long id) {
        log.debug("REST request to get Enfant : {}", id);
        EnfantDTO enfantDTO = enfantService.findOne(id);
        return ResponseUtil.wrapOrNotFound(Optional.ofNullable(enfantDTO));
    }

    /**
     * DELETE  /enfants/:id : delete the "id" enfant.
     *
     * @param id the id of the enfantDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/enfants/{id}")
    @Timed
    public ResponseEntity<Void> deleteEnfant(@PathVariable Long id) {
        log.debug("REST request to delete Enfant : {}", id);
        enfantService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
