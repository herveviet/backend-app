import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { Enfant } from './enfant.model';
import { EnfantPopupService } from './enfant-popup.service';
import { EnfantService } from './enfant.service';

@Component({
    selector: 'jhi-enfant-delete-dialog',
    templateUrl: './enfant-delete-dialog.component.html'
})
export class EnfantDeleteDialogComponent {

    enfant: Enfant;

    constructor(
        private enfantService: EnfantService,
        public activeModal: NgbActiveModal,
        private eventManager: JhiEventManager
    ) {
    }

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(id: number) {
        this.enfantService.delete(id).subscribe((response) => {
            this.eventManager.broadcast({
                name: 'enfantListModification',
                content: 'Deleted an enfant'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'jhi-enfant-delete-popup',
    template: ''
})
export class EnfantDeletePopupComponent implements OnInit, OnDestroy {

    routeSub: any;

    constructor(
        private route: ActivatedRoute,
        private enfantPopupService: EnfantPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe((params) => {
            this.enfantPopupService
                .open(EnfantDeleteDialogComponent as Component, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
