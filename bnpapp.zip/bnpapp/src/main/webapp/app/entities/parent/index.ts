export * from './parent.model';
export * from './parent-popup.service';
export * from './parent.service';
export * from './parent-dialog.component';
export * from './parent-delete-dialog.component';
export * from './parent-detail.component';
export * from './parent.component';
export * from './parent.route';
