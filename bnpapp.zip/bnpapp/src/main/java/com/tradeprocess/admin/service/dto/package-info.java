/**
 * Data Transfer Objects.
 */
package com.tradeprocess.admin.service.dto;
