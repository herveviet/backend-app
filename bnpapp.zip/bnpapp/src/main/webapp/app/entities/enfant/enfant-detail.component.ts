import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse } from '@angular/common/http';
import { Subscription } from 'rxjs/Subscription';
import { JhiEventManager } from 'ng-jhipster';

import { Enfant } from './enfant.model';
import { EnfantService } from './enfant.service';

@Component({
    selector: 'jhi-enfant-detail',
    templateUrl: './enfant-detail.component.html'
})
export class EnfantDetailComponent implements OnInit, OnDestroy {

    enfant: Enfant;
    private subscription: Subscription;
    private eventSubscriber: Subscription;

    constructor(
        private eventManager: JhiEventManager,
        private enfantService: EnfantService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe((params) => {
            this.load(params['id']);
        });
        this.registerChangeInEnfants();
    }

    load(id) {
        this.enfantService.find(id)
            .subscribe((enfantResponse: HttpResponse<Enfant>) => {
                this.enfant = enfantResponse.body;
            });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
        this.eventManager.destroy(this.eventSubscriber);
    }

    registerChangeInEnfants() {
        this.eventSubscriber = this.eventManager.subscribe(
            'enfantListModification',
            (response) => this.load(this.enfant.id)
        );
    }
}
