package com.tradeprocess.admin.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.tradeprocess.admin.service.ParentService;
import com.tradeprocess.admin.web.rest.errors.BadRequestAlertException;
import com.tradeprocess.admin.web.rest.util.HeaderUtil;
import com.tradeprocess.admin.web.rest.util.PaginationUtil;
import com.tradeprocess.admin.service.dto.ParentDTO;
import com.tradeprocess.admin.service.dto.ParentCriteria;
import com.tradeprocess.admin.service.ParentQueryService;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Parent.
 */
@RestController
@RequestMapping("/api")
public class ParentResource {

    private final Logger log = LoggerFactory.getLogger(ParentResource.class);

    private static final String ENTITY_NAME = "parent";

    private final ParentService parentService;

    private final ParentQueryService parentQueryService;

    public ParentResource(ParentService parentService, ParentQueryService parentQueryService) {
        this.parentService = parentService;
        this.parentQueryService = parentQueryService;
    }

    /**
     * POST  /parents : Create a new parent.
     *
     * @param parentDTO the parentDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new parentDTO, or with status 400 (Bad Request) if the parent has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/parents")
    @Timed
    public ResponseEntity<ParentDTO> createParent(@RequestBody ParentDTO parentDTO) throws URISyntaxException {
        log.debug("REST request to save Parent : {}", parentDTO);
        if (parentDTO.getId() != null) {
            throw new BadRequestAlertException("A new parent cannot already have an ID", ENTITY_NAME, "idexists");
        }
        ParentDTO result = parentService.save(parentDTO);
        return ResponseEntity.created(new URI("/api/parents/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /parents : Updates an existing parent.
     *
     * @param parentDTO the parentDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated parentDTO,
     * or with status 400 (Bad Request) if the parentDTO is not valid,
     * or with status 500 (Internal Server Error) if the parentDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/parents")
    @Timed
    public ResponseEntity<ParentDTO> updateParent(@RequestBody ParentDTO parentDTO) throws URISyntaxException {
        log.debug("REST request to update Parent : {}", parentDTO);
        if (parentDTO.getId() == null) {
            return createParent(parentDTO);
        }
        ParentDTO result = parentService.save(parentDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, parentDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /parents : get all the parents.
     *
     * @param pageable the pagination information
     * @param criteria the criterias which the requested entities should match
     * @return the ResponseEntity with status 200 (OK) and the list of parents in body
     */
    @GetMapping("/parents")
    @Timed
    public ResponseEntity<List<ParentDTO>> getAllParents(ParentCriteria criteria, Pageable pageable) {
        log.debug("REST request to get Parents by criteria: {}", criteria);
        Page<ParentDTO> page = parentQueryService.findByCriteria(criteria, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/parents");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }

    /**
     * GET  /parents/:id : get the "id" parent.
     *
     * @param id the id of the parentDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the parentDTO, or with status 404 (Not Found)
     */
    @GetMapping("/parents/{id}")
    @Timed
    public ResponseEntity<ParentDTO> getParent(@PathVariable Long id) {
        log.debug("REST request to get Parent : {}", id);
        ParentDTO parentDTO = parentService.findOne(id);
        return ResponseUtil.wrapOrNotFound(Optional.ofNullable(parentDTO));
    }

    /**
     * DELETE  /parents/:id : delete the "id" parent.
     *
     * @param id the id of the parentDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/parents/{id}")
    @Timed
    public ResponseEntity<Void> deleteParent(@PathVariable Long id) {
        log.debug("REST request to delete Parent : {}", id);
        parentService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
