import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { TradeprocessadminSharedModule } from '../../shared';
import {
    EnfantService,
    EnfantPopupService,
    EnfantComponent,
    EnfantDetailComponent,
    EnfantDialogComponent,
    EnfantPopupComponent,
    EnfantDeletePopupComponent,
    EnfantDeleteDialogComponent,
    enfantRoute,
    enfantPopupRoute,
} from './';

const ENTITY_STATES = [
    ...enfantRoute,
    ...enfantPopupRoute,
];

@NgModule({
    imports: [
        TradeprocessadminSharedModule,
        RouterModule.forChild(ENTITY_STATES)
    ],
    declarations: [
        EnfantComponent,
        EnfantDetailComponent,
        EnfantDialogComponent,
        EnfantDeleteDialogComponent,
        EnfantPopupComponent,
        EnfantDeletePopupComponent,
    ],
    entryComponents: [
        EnfantComponent,
        EnfantDialogComponent,
        EnfantPopupComponent,
        EnfantDeleteDialogComponent,
        EnfantDeletePopupComponent,
    ],
    providers: [
        EnfantService,
        EnfantPopupService,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class TradeprocessadminEnfantModule {}
