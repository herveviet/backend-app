/**
 * View Models used by Spring MVC REST controllers.
 */
package com.tradeprocess.admin.web.rest.vm;
