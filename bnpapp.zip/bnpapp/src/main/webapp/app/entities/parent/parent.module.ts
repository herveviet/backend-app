import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { TradeprocessadminSharedModule } from '../../shared';
import {
    ParentService,
    ParentPopupService,
    ParentComponent,
    ParentDetailComponent,
    ParentDialogComponent,
    ParentPopupComponent,
    ParentDeletePopupComponent,
    ParentDeleteDialogComponent,
    parentRoute,
    parentPopupRoute,
} from './';

const ENTITY_STATES = [
    ...parentRoute,
    ...parentPopupRoute,
];

@NgModule({
    imports: [
        TradeprocessadminSharedModule,
        RouterModule.forChild(ENTITY_STATES)
    ],
    declarations: [
        ParentComponent,
        ParentDetailComponent,
        ParentDialogComponent,
        ParentDeleteDialogComponent,
        ParentPopupComponent,
        ParentDeletePopupComponent,
    ],
    entryComponents: [
        ParentComponent,
        ParentDialogComponent,
        ParentPopupComponent,
        ParentDeleteDialogComponent,
        ParentDeletePopupComponent,
    ],
    providers: [
        ParentService,
        ParentPopupService,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class TradeprocessadminParentModule {}
