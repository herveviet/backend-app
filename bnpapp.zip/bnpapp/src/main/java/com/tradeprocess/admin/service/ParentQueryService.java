package com.tradeprocess.admin.service;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import io.github.jhipster.service.QueryService;

import com.tradeprocess.admin.domain.Parent;
import com.tradeprocess.admin.domain.*; // for static metamodels
import com.tradeprocess.admin.repository.ParentRepository;
import com.tradeprocess.admin.service.dto.ParentCriteria;

import com.tradeprocess.admin.service.dto.ParentDTO;
import com.tradeprocess.admin.service.mapper.ParentMapper;

/**
 * Service for executing complex queries for Parent entities in the database.
 * The main input is a {@link ParentCriteria} which get's converted to {@link Specifications},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link ParentDTO} or a {@link Page} of {@link ParentDTO} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class ParentQueryService extends QueryService<Parent> {

    private final Logger log = LoggerFactory.getLogger(ParentQueryService.class);


    private final ParentRepository parentRepository;

    private final ParentMapper parentMapper;

    public ParentQueryService(ParentRepository parentRepository, ParentMapper parentMapper) {
        this.parentRepository = parentRepository;
        this.parentMapper = parentMapper;
    }

    /**
     * Return a {@link List} of {@link ParentDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public List<ParentDTO> findByCriteria(ParentCriteria criteria) {
        log.debug("find by criteria : {}", criteria);
        final Specifications<Parent> specification = createSpecification(criteria);
        return parentMapper.toDto(parentRepository.findAll(specification));
    }

    /**
     * Return a {@link Page} of {@link ParentDTO} which matches the criteria from the database
     * @param criteria The object which holds all the filters, which the entities should match.
     * @param page The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<ParentDTO> findByCriteria(ParentCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specifications<Parent> specification = createSpecification(criteria);
        final Page<Parent> result = parentRepository.findAll(specification, page);
        return result.map(parentMapper::toDto);
    }

    /**
     * Function to convert ParentCriteria to a {@link Specifications}
     */
    private Specifications<Parent> createSpecification(ParentCriteria criteria) {
        Specifications<Parent> specification = Specifications.where(null);
        if (criteria != null) {
            if (criteria.getId() != null) {
                specification = specification.and(buildSpecification(criteria.getId(), Parent_.id));
            }
            if (criteria.getName() != null) {
                specification = specification.and(buildStringSpecification(criteria.getName(), Parent_.name));
            }
            if (criteria.getAge() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getAge(), Parent_.age));
            }
            if (criteria.getFonction() != null) {
                specification = specification.and(buildStringSpecification(criteria.getFonction(), Parent_.fonction));
            }
        }
        return specification;
    }

}
