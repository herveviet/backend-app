import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { TradeprocessadminParentModule } from './parent/parent.module';
import { TradeprocessadminEnfantModule } from './enfant/enfant.module';
/* jhipster-needle-add-entity-module-import - JHipster will add entity modules imports here */

@NgModule({
    imports: [
        TradeprocessadminParentModule,
        TradeprocessadminEnfantModule,
        /* jhipster-needle-add-entity-module - JHipster will add entity modules here */
    ],
    declarations: [],
    entryComponents: [],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class TradeprocessadminEntityModule {}
