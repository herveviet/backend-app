package com.tradeprocess.admin.domain.enumeration;

/**
 * The Type enumeration.
 */
public enum Type {
    type1, type2, type3
}
