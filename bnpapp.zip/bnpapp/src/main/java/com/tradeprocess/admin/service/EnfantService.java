package com.tradeprocess.admin.service;

import com.tradeprocess.admin.service.dto.EnfantDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing Enfant.
 */
public interface EnfantService {

    /**
     * Save a enfant.
     *
     * @param enfantDTO the entity to save
     * @return the persisted entity
     */
    EnfantDTO save(EnfantDTO enfantDTO);

    /**
     * Get all the enfants.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    Page<EnfantDTO> findAll(Pageable pageable);

    /**
     * Get the "id" enfant.
     *
     * @param id the id of the entity
     * @return the entity
     */
    EnfantDTO findOne(Long id);

    /**
     * Delete the "id" enfant.
     *
     * @param id the id of the entity
     */
    void delete(Long id);
}
