import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { SERVER_API_URL } from '../../app.constants';

import { JhiDateUtils } from 'ng-jhipster';

import { Enfant } from './enfant.model';
import { createRequestOption } from '../../shared';

export type EntityResponseType = HttpResponse<Enfant>;

@Injectable()
export class EnfantService {

    private resourceUrl =  SERVER_API_URL + 'api/enfants';

    constructor(private http: HttpClient, private dateUtils: JhiDateUtils) { }

    create(enfant: Enfant): Observable<EntityResponseType> {
        const copy = this.convert(enfant);
        return this.http.post<Enfant>(this.resourceUrl, copy, { observe: 'response' })
            .map((res: EntityResponseType) => this.convertResponse(res));
    }

    update(enfant: Enfant): Observable<EntityResponseType> {
        const copy = this.convert(enfant);
        return this.http.put<Enfant>(this.resourceUrl, copy, { observe: 'response' })
            .map((res: EntityResponseType) => this.convertResponse(res));
    }

    find(id: number): Observable<EntityResponseType> {
        return this.http.get<Enfant>(`${this.resourceUrl}/${id}`, { observe: 'response'})
            .map((res: EntityResponseType) => this.convertResponse(res));
    }

    query(req?: any): Observable<HttpResponse<Enfant[]>> {
        const options = createRequestOption(req);
        return this.http.get<Enfant[]>(this.resourceUrl, { params: options, observe: 'response' })
            .map((res: HttpResponse<Enfant[]>) => this.convertArrayResponse(res));
    }

    delete(id: number): Observable<HttpResponse<any>> {
        return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response'});
    }

    private convertResponse(res: EntityResponseType): EntityResponseType {
        const body: Enfant = this.convertItemFromServer(res.body);
        return res.clone({body});
    }

    private convertArrayResponse(res: HttpResponse<Enfant[]>): HttpResponse<Enfant[]> {
        const jsonResponse: Enfant[] = res.body;
        const body: Enfant[] = [];
        for (let i = 0; i < jsonResponse.length; i++) {
            body.push(this.convertItemFromServer(jsonResponse[i]));
        }
        return res.clone({body});
    }

    /**
     * Convert a returned JSON object to Enfant.
     */
    private convertItemFromServer(enfant: Enfant): Enfant {
        const copy: Enfant = Object.assign({}, enfant);
        copy.dateNaiss = this.dateUtils
            .convertDateTimeFromServer(enfant.dateNaiss);
        copy.field2 = this.dateUtils
            .convertDateTimeFromServer(enfant.field2);
        return copy;
    }

    /**
     * Convert a Enfant to a JSON which can be sent to the server.
     */
    private convert(enfant: Enfant): Enfant {
        const copy: Enfant = Object.assign({}, enfant);

        copy.dateNaiss = this.dateUtils.toDate(enfant.dateNaiss);

        copy.field2 = this.dateUtils.toDate(enfant.field2);
        return copy;
    }
}
