import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { HttpResponse } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { Enfant } from './enfant.model';
import { EnfantService } from './enfant.service';

@Injectable()
export class EnfantPopupService {
    private ngbModalRef: NgbModalRef;

    constructor(
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private enfantService: EnfantService

    ) {
        this.ngbModalRef = null;
    }

    open(component: Component, id?: number | any): Promise<NgbModalRef> {
        return new Promise<NgbModalRef>((resolve, reject) => {
            const isOpen = this.ngbModalRef !== null;
            if (isOpen) {
                resolve(this.ngbModalRef);
            }

            if (id) {
                this.enfantService.find(id)
                    .subscribe((enfantResponse: HttpResponse<Enfant>) => {
                        const enfant: Enfant = enfantResponse.body;
                        enfant.dateNaiss = this.datePipe
                            .transform(enfant.dateNaiss, 'yyyy-MM-ddTHH:mm:ss');
                        enfant.field2 = this.datePipe
                            .transform(enfant.field2, 'yyyy-MM-ddTHH:mm:ss');
                        this.ngbModalRef = this.enfantModalRef(component, enfant);
                        resolve(this.ngbModalRef);
                    });
            } else {
                // setTimeout used as a workaround for getting ExpressionChangedAfterItHasBeenCheckedError
                setTimeout(() => {
                    this.ngbModalRef = this.enfantModalRef(component, new Enfant());
                    resolve(this.ngbModalRef);
                }, 0);
            }
        });
    }

    enfantModalRef(component: Component, enfant: Enfant): NgbModalRef {
        const modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.enfant = enfant;
        modalRef.result.then((result) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true, queryParamsHandling: 'merge' });
            this.ngbModalRef = null;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true, queryParamsHandling: 'merge' });
            this.ngbModalRef = null;
        });
        return modalRef;
    }
}
