import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager, JhiAlertService } from 'ng-jhipster';

import { Enfant } from './enfant.model';
import { EnfantPopupService } from './enfant-popup.service';
import { EnfantService } from './enfant.service';
import { Parent, ParentService } from '../parent';

@Component({
    selector: 'jhi-enfant-dialog',
    templateUrl: './enfant-dialog.component.html'
})
export class EnfantDialogComponent implements OnInit {

    enfant: Enfant;
    isSaving: boolean;

    parents: Parent[];

    constructor(
        public activeModal: NgbActiveModal,
        private jhiAlertService: JhiAlertService,
        private enfantService: EnfantService,
        private parentService: ParentService,
        private eventManager: JhiEventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.parentService.query()
            .subscribe((res: HttpResponse<Parent[]>) => { this.parents = res.body; }, (res: HttpErrorResponse) => this.onError(res.message));
    }

    clear() {
        this.activeModal.dismiss('cancel');
    }

    save() {
        this.isSaving = true;
        if (this.enfant.id !== undefined) {
            this.subscribeToSaveResponse(
                this.enfantService.update(this.enfant));
        } else {
            this.subscribeToSaveResponse(
                this.enfantService.create(this.enfant));
        }
    }

    private subscribeToSaveResponse(result: Observable<HttpResponse<Enfant>>) {
        result.subscribe((res: HttpResponse<Enfant>) =>
            this.onSaveSuccess(res.body), (res: HttpErrorResponse) => this.onSaveError());
    }

    private onSaveSuccess(result: Enfant) {
        this.eventManager.broadcast({ name: 'enfantListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError() {
        this.isSaving = false;
    }

    private onError(error: any) {
        this.jhiAlertService.error(error.message, null, null);
    }

    trackParentById(index: number, item: Parent) {
        return item.id;
    }
}

@Component({
    selector: 'jhi-enfant-popup',
    template: ''
})
export class EnfantPopupComponent implements OnInit, OnDestroy {

    routeSub: any;

    constructor(
        private route: ActivatedRoute,
        private enfantPopupService: EnfantPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe((params) => {
            if ( params['id'] ) {
                this.enfantPopupService
                    .open(EnfantDialogComponent as Component, params['id']);
            } else {
                this.enfantPopupService
                    .open(EnfantDialogComponent as Component);
            }
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
